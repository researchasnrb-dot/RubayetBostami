
export interface Publication {
  id: string;
  title: string;
  journal: string;
  year: number;
  authors: string;
  link?: string;
}

export interface ResearchCard {
  title: string;
  description: string;
  icon: string;
  imageUrl: string;
}

export interface GalleryItem {
  id: string;
  url: string;
  caption: string;
  category: 'Field' | 'Academic' | 'Lab';
}
