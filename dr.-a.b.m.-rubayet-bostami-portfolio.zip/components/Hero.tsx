
import React from 'react';
import { ArrowRight, BookOpen, Microscope } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-white">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/4 w-[800px] h-[800px] bg-emerald-50 rounded-full blur-3xl opacity-50 z-0"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-8">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold uppercase tracking-wider">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>Available for Research Collaboration</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-slate-900 leading-[1.1]">
              Pioneering <span className="text-emerald-900 italic">Animal Science</span> for Global Food Safety.
            </h1>
            
            <p className="text-lg text-slate-600 max-w-2xl leading-relaxed">
              Dr. A.B.M. Rubayet Bostami is the Professor & Head of Animal Science at GAU. With a PhD from Sunchon National University, Korea, his work bridges the gap between high-yield ruminant nutrition and sustainable meat quality.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center gap-4 pt-4">
              <a 
                href="#research" 
                className="w-full sm:w-auto px-8 py-4 bg-emerald-900 text-white rounded-xl font-bold flex items-center justify-center space-x-2 hover:bg-emerald-800 transition-all shadow-xl shadow-emerald-900/20 group"
              >
                <span>View Research Pillars</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
              <a 
                href="https://www.researchgate.net/profile/Abmrubayet-Bostami" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-8 py-4 bg-white text-slate-900 border border-slate-200 rounded-xl font-bold flex items-center justify-center space-x-2 hover:bg-slate-50 transition-all"
              >
                <BookOpen className="w-5 h-5 text-emerald-700" />
                <span>Publications</span>
              </a>
            </div>

            <div className="grid grid-cols-3 gap-8 pt-8 border-t border-slate-100">
              <div>
                <p className="text-2xl font-bold text-slate-900">50+</p>
                <p className="text-sm text-slate-500">Publications</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">15+</p>
                <p className="text-sm text-slate-500">Research Grants</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">1.2k</p>
                <p className="text-sm text-slate-500">Citations</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 relative hidden lg:block">
            <div className="relative z-10 rounded-[2rem] overflow-hidden shadow-2xl border-4 border-white aspect-[4/5] bg-emerald-900 flex flex-col items-center justify-center p-12 text-center group">
              <div className="mb-8 p-6 bg-white/10 rounded-full group-hover:scale-110 transition-transform duration-500">
                <Microscope className="w-24 h-24 text-emerald-200" />
              </div>
              <div className="space-y-2">
                <h2 className="text-4xl font-serif font-bold text-white">DR. ARB</h2>
                <div className="w-12 h-1 bg-emerald-400 mx-auto rounded-full"></div>
                <p className="text-emerald-100/70 text-sm uppercase tracking-widest font-bold pt-2">Scientific Integrity</p>
              </div>
              
              <div className="absolute top-0 right-0 p-8 opacity-10">
                 <div className="text-8xl font-serif font-bold text-white leading-none">GAU</div>
              </div>
            </div>
            
            {/* Decorative Elements */}
            <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-emerald-100 rounded-2xl -z-10 rotate-12"></div>
            <div className="absolute -top-6 -right-6 w-32 h-32 bg-slate-100 rounded-full -z-10"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
