
import React from 'react';
import { RESEARCH_PILLARS } from '../constants';

const ResearchPillars: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
        <div className="max-w-2xl">
          <h2 className="text-emerald-900 font-bold uppercase tracking-widest text-sm mb-4">Core Expertise</h2>
          <h3 className="text-4xl font-serif font-bold text-slate-900">Research Pillars</h3>
          <p className="mt-4 text-slate-600">
            Applying advanced molecular and nutritional methodologies to enhance the quality, safety, and productivity of animal-origin foods.
          </p>
        </div>
        <div className="hidden md:block">
           <a href="https://www.researchgate.net/profile/Abmrubayet-Bostami" target="_blank" className="text-emerald-900 font-bold hover:underline flex items-center gap-2">
             Explore all research projects
             <span>&rarr;</span>
           </a>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {RESEARCH_PILLARS.map((pillar, idx) => (
          <div 
            key={idx} 
            className={`group relative rounded-3xl p-8 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 hover:-translate-y-2 border border-slate-100 ${pillar.color}`}
          >
            <div className="relative z-10 h-full flex flex-col">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mb-8 shadow-sm group-hover:scale-110 transition-transform duration-300">
                {pillar.icon}
              </div>
              <h4 className="text-2xl font-serif font-bold mb-4">{pillar.title}</h4>
              <p className="text-sm opacity-80 leading-relaxed mb-6 flex-grow">
                {pillar.description}
              </p>
              <div className="h-1 w-0 bg-current group-hover:w-full transition-all duration-500 opacity-20"></div>
            </div>
            
            {/* Background Decorative Element */}
            <div className="absolute -bottom-8 -right-8 opacity-5 group-hover:scale-125 transition-transform duration-700">
              <div className="scale-[2.5]">{pillar.icon}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ResearchPillars;
