
import React from 'react';
import { FileText, Download, ExternalLink, Filter } from 'lucide-react';
import { PUBLICATIONS } from '../constants';

const Publications: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
        <div className="lg:col-span-4 space-y-8">
          <div>
            <h2 className="text-emerald-900 font-bold uppercase tracking-widest text-sm mb-4">Scientific Impact</h2>
            <h3 className="text-4xl font-serif font-bold text-slate-900">Publication Feed</h3>
          </div>
          
          <p className="text-slate-600">
            A curated selection of peer-reviewed articles and conference papers focusing on livestock nutrition and food safety technologies.
          </p>

          <div className="p-8 bg-slate-900 rounded-3xl text-white">
            <h4 className="font-bold mb-4 flex items-center space-x-2">
              <ExternalLink className="w-5 h-5 text-emerald-400" />
              <span>Full Bibliography</span>
            </h4>
            <p className="text-sm text-slate-400 mb-6 leading-relaxed">
              Access the complete list of 50+ publications, conference proceedings, and book chapters on professional networks.
            </p>
            <div className="space-y-3">
              <a 
                href="https://www.researchgate.net/profile/Abmrubayet-Bostami" 
                target="_blank" 
                className="block w-full text-center py-3 bg-white text-slate-900 rounded-xl font-bold hover:bg-emerald-50 transition-colors"
              >
                ResearchGate
              </a>
              <a 
                href="#" 
                className="block w-full text-center py-3 border border-white/20 text-white rounded-xl font-bold hover:bg-white/10 transition-colors"
              >
                Google Scholar
              </a>
            </div>
          </div>
        </div>

        <div className="lg:col-span-8">
          <div className="flex items-center justify-between mb-8 pb-4 border-b border-slate-100">
             <div className="flex space-x-4">
               <button className="text-sm font-bold text-emerald-900 px-4 py-2 bg-emerald-50 rounded-lg">Recent</button>
               <button className="text-sm font-medium text-slate-500 hover:text-emerald-900 px-4 py-2">Most Cited</button>
             </div>
             <button className="text-slate-400 hover:text-slate-600">
               <Filter className="w-5 h-5" />
             </button>
          </div>

          <div className="space-y-6">
            {PUBLICATIONS.map((pub) => (
              <div 
                key={pub.id} 
                className="group p-6 rounded-2xl border border-slate-100 hover:border-emerald-200 hover:bg-emerald-50/20 transition-all flex gap-6"
              >
                <div className="hidden sm:flex flex-col items-center justify-center w-16 h-16 bg-slate-50 rounded-xl border border-slate-100 text-slate-400 group-hover:text-emerald-600 group-hover:border-emerald-100 transition-colors">
                  <span className="text-xs font-bold">{pub.year}</span>
                  <FileText className="w-6 h-6" />
                </div>
                
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-4">
                    <h5 className="text-lg font-bold text-slate-900 group-hover:text-emerald-900 transition-colors leading-tight">
                      {pub.title}
                    </h5>
                    <a href={pub.link} target="_blank" className="p-2 text-slate-400 hover:text-emerald-600 transition-colors">
                      <Download className="w-5 h-5" />
                    </a>
                  </div>
                  <p className="text-sm text-slate-500 mt-2 font-medium">{pub.authors}</p>
                  <p className="text-xs text-emerald-700 font-bold uppercase tracking-wider mt-4">{pub.journal}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 p-6 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between">
            <span className="text-sm text-slate-500">Showing {PUBLICATIONS.length} of 50+ publications</span>
            <button className="text-emerald-900 font-bold text-sm flex items-center gap-2 hover:gap-3 transition-all">
              Load More <span>&rarr;</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Publications;
