
import React from 'react';
import { Mail, Phone, MapPin, Linkedin, Facebook, Microscope, Twitter, Globe } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-emerald-950 text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 mb-20">
          <div className="lg:col-span-5 space-y-8">
            <div className="flex items-center space-x-2">
              <Microscope className="w-10 h-10 text-emerald-400" />
              <div className="flex flex-col">
                <span className="text-2xl font-bold tracking-tight font-serif">Dr. Rubayet Bostami</span>
                <span className="text-xs uppercase tracking-[0.2em] text-emerald-400/80 font-medium">Academic & Research Portfolio</span>
              </div>
            </div>
            
            <p className="text-emerald-100/60 leading-relaxed max-w-md">
              Committed to advancing the frontiers of animal science and ensuring global food safety through innovation, research, and dedicated education at Gazipur Agricultural University.
            </p>

            <div className="flex items-center space-x-4">
              <a href="#" className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center hover:bg-emerald-600 transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="https://www.facebook.com/rubayet.bostami" target="_blank" className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center hover:bg-emerald-600 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center hover:bg-emerald-600 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center hover:bg-emerald-600 transition-colors">
                <Globe className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-6">
              <h4 className="text-lg font-bold text-white border-b border-white/10 pb-4">Contact Details</h4>
              <ul className="space-y-4">
                <li className="flex items-start space-x-4">
                  <Mail className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div className="flex flex-col">
                    <span className="text-xs text-emerald-400 font-bold uppercase">Email</span>
                    <a href="mailto:rubayet@gau.edu.bd" className="text-emerald-100 hover:text-white transition-colors">rubayet@gau.edu.bd</a>
                  </div>
                </li>
                <li className="flex items-start space-x-4">
                  <Phone className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div className="flex flex-col">
                    <span className="text-xs text-emerald-400 font-bold uppercase">Direct Phone</span>
                    <span className="text-emerald-100">+880 1716632251</span>
                  </div>
                </li>
                <li className="flex items-start space-x-4">
                  <MapPin className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div className="flex flex-col">
                    <span className="text-xs text-emerald-400 font-bold uppercase">Office Location</span>
                    <span className="text-emerald-100 leading-relaxed">
                      Faculty of Animal Science, Gazipur Agricultural University, Gazipur-1706, Bangladesh.
                    </span>
                  </div>
                </li>
              </ul>
            </div>

            <div className="space-y-6">
              <h4 className="text-lg font-bold text-white border-b border-white/10 pb-4">Institutional Links</h4>
              <ul className="space-y-4">
                <li><a href="#" className="text-emerald-100/70 hover:text-white transition-colors flex items-center gap-2 group">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 group-hover:bg-emerald-400"></span>
                  GAU Official Website
                </a></li>
                <li><a href="#" className="text-emerald-100/70 hover:text-white transition-colors flex items-center gap-2 group">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 group-hover:bg-emerald-400"></span>
                  Dept. of Animal Science
                </a></li>
                <li><a href="#" className="text-emerald-100/70 hover:text-white transition-colors flex items-center gap-2 group">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 group-hover:bg-emerald-400"></span>
                  University Research Council
                </a></li>
                <li><a href="#" className="text-emerald-100/70 hover:text-white transition-colors flex items-center gap-2 group">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 group-hover:bg-emerald-400"></span>
                  Journal Submission Portal
                </a></li>
              </ul>
            </div>
          </div>
        </div>

        <div className="pt-10 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-6 text-sm text-emerald-100/40">
          <p>&copy; {new Date().getFullYear()} Dr. A.B.M. Rubayet Bostami. All Rights Reserved.</p>
          <div className="flex items-center space-x-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Use</a>
            <a href="#" className="hover:text-white transition-colors">Accessibility</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
