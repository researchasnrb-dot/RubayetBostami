
import React, { useState } from 'react';
import { Camera, ExternalLink } from 'lucide-react';
import { PROFESSIONAL_HIGHLIGHTS } from '../constants';

const Gallery: React.FC = () => {
  const [filter, setFilter] = useState<'All' | 'Field' | 'Academic' | 'Lab'>('All');

  const filteredItems = filter === 'All' 
    ? PROFESSIONAL_HIGHLIGHTS 
    : PROFESSIONAL_HIGHLIGHTS.filter(item => item.category === filter);

  const categories: ('All' | 'Field' | 'Academic' | 'Lab')[] = ['All', 'Field', 'Academic', 'Lab'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h2 className="text-emerald-900 font-bold uppercase tracking-widest text-sm mb-4">Activity Timeline</h2>
        <h3 className="text-4xl font-serif font-bold text-slate-900">Research & Field Insights</h3>
        
        <div className="flex flex-wrap justify-center gap-2 mt-8">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${
                filter === cat 
                  ? 'bg-emerald-900 text-white shadow-lg' 
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((item) => (
          <div 
            key={item.id} 
            className="group relative p-8 rounded-3xl bg-white border border-slate-100 hover:border-emerald-200 hover:shadow-xl transition-all duration-300"
          >
            <div className="flex flex-col h-full">
              <div className="w-12 h-12 bg-emerald-50 text-emerald-900 rounded-xl flex items-center justify-center mb-6 group-hover:bg-emerald-900 group-hover:text-white transition-colors">
                {/* Fix: Cast icon to React.ReactElement<any> to resolve TypeScript error regarding className property */}
                {React.cloneElement(item.icon as React.ReactElement<any>, { className: "w-6 h-6" })}
              </div>
              <div className="mb-4">
                <span className="text-emerald-700 text-[10px] font-bold uppercase tracking-widest">{item.category}</span>
                <h4 className="text-xl font-bold text-slate-900 mt-1">{item.title}</h4>
              </div>
              <p className="text-slate-600 text-sm leading-relaxed flex-grow">
                {item.desc}
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-16 bg-white p-8 rounded-3xl border border-slate-100 flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-900">
             <Camera className="w-8 h-8" />
          </div>
          <div>
            <h4 className="text-xl font-bold text-slate-900">Media & Official Archives</h4>
            <p className="text-slate-500">Documenting a career of scientific inquiry and livestock advancement.</p>
          </div>
        </div>
        <a 
          href="https://www.facebook.com/rubayet.bostami" 
          target="_blank"
          className="px-8 py-3 bg-emerald-50 text-emerald-900 font-bold rounded-xl hover:bg-emerald-100 transition-colors flex items-center gap-2"
        >
          <ExternalLink className="w-4 h-4" />
          Follow Updates
        </a>
      </div>
    </div>
  );
};

export default Gallery;
