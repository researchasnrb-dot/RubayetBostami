
import React from 'react';
import { GraduationCap, Award, Building2, MapPin } from 'lucide-react';

const Credentials: React.FC = () => {
  const education = [
    {
      degree: "Doctor of Philosophy (PhD)",
      institution: "Sunchon National University, South Korea",
      year: "2015",
      specialization: "Animal Nutrition & Meat Science",
      icon: <GraduationCap className="w-6 h-6" />
    },
    {
      degree: "Master of Science (MS)",
      institution: "Bangladesh Agricultural University",
      year: "2010",
      specialization: "Animal Science",
      icon: <GraduationCap className="w-6 h-6" />
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-16">
        <h2 className="text-emerald-900 font-bold uppercase tracking-widest text-sm mb-4">Academic Background</h2>
        <h3 className="text-4xl font-serif font-bold text-slate-900">Leadership & Education</h3>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        <div className="space-y-12">
          <div className="bg-emerald-900 rounded-3xl p-8 text-white shadow-2xl relative overflow-hidden group">
             <Building2 className="absolute top-4 right-4 w-24 h-24 text-white/5 group-hover:scale-110 transition-transform" />
             <div className="relative z-10">
               <h4 className="text-emerald-200 uppercase tracking-widest text-xs font-bold mb-2">Current Position</h4>
               <p className="text-3xl font-serif font-bold mb-4">Professor & Head</p>
               <p className="text-xl font-medium mb-6">Department of Animal Science and Nutrition</p>
               <div className="flex items-center space-x-2 text-emerald-100/80">
                 <MapPin className="w-5 h-5" />
                 <span>Gazipur Agricultural University (GAU), Bangladesh</span>
               </div>
             </div>
          </div>

          <div className="space-y-6">
            <h4 className="text-xl font-bold text-slate-900 flex items-center space-x-2">
              <Award className="w-6 h-6 text-emerald-600" />
              <span>Honors & Recognitions</span>
            </h4>
            <ul className="space-y-4">
              {[
                "Best Researcher Award - GAU 2021",
                "Brain Korea 21 (BK21) Fellowship recipient",
                "Associate Editor - International Journal of Livestock Research",
                "Technical Advisor to Meat Processing Federations"
              ].map((item, idx) => (
                <li key={idx} className="flex items-start space-x-3 p-4 bg-slate-50 rounded-xl hover:bg-emerald-50 transition-colors group">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 mt-2 group-hover:scale-150 transition-transform"></span>
                  <span className="text-slate-700 font-medium">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="space-y-8">
          <h4 className="text-xl font-bold text-slate-900 flex items-center space-x-2">
            <GraduationCap className="w-6 h-6 text-emerald-600" />
            <span>Academic Pathway</span>
          </h4>
          
          <div className="relative space-y-12 before:absolute before:left-[1.75rem] before:top-4 before:bottom-4 before:w-px before:bg-slate-200">
            {education.map((edu, idx) => (
              <div key={idx} className="relative pl-14">
                <div className="absolute left-0 top-0 w-14 h-14 bg-white border-2 border-slate-100 rounded-2xl flex items-center justify-center text-emerald-900 shadow-sm z-10">
                  {edu.icon}
                </div>
                <div>
                  <span className="inline-block px-3 py-1 rounded-full bg-slate-100 text-slate-600 text-xs font-bold mb-2">
                    Class of {edu.year}
                  </span>
                  <h5 className="text-xl font-bold text-slate-900">{edu.degree}</h5>
                  <p className="text-emerald-800 font-medium mb-1">{edu.institution}</p>
                  <p className="text-slate-500 text-sm">{edu.specialization}</p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="p-8 rounded-3xl border border-emerald-100 bg-emerald-50/50">
            <p className="text-slate-600 italic leading-relaxed">
              "My academic journey from Bangladesh to South Korea has shaped a global perspective on food security. I believe the future of nutrition lies in the intersection of traditional animal husbandry and modern biotechnology."
            </p>
            <p className="mt-4 font-serif font-bold text-emerald-900">— Dr. Rubayet Bostami</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Credentials;
