
import React from 'react';
import { Beaker, ShieldCheck, Beef, Leaf, Microscope, Users, BookOpen, GraduationCap, FlaskConical, Globe } from 'lucide-react';

export const RESEARCH_PILLARS = [
  {
    title: "Meat Science",
    description: "In-depth research on meat quality parameters, shelf-life extension, and consumer preferences for sustainable meat production.",
    icon: <Beef className="w-10 h-10" />,
    color: "bg-emerald-50 text-emerald-900"
  },
  {
    title: "Ruminant Nutrition",
    description: "Developing specialized feed formulations to optimize growth performance and metabolic health in ruminants.",
    icon: <Leaf className="w-10 h-10" />,
    color: "bg-slate-50 text-slate-900"
  },
  {
    title: "Food Safety",
    description: "Implementing rigorous testing protocols for chemical and microbial contaminants in the food supply chain.",
    icon: <ShieldCheck className="w-10 h-10" />,
    color: "bg-emerald-50 text-emerald-900"
  },
  {
    title: "Feed Additives",
    description: "Exploring natural and synthetic additives that enhance nutrient bioavailability and livestock productivity.",
    icon: <Beaker className="w-10 h-10" />,
    color: "bg-slate-50 text-slate-900"
  }
];

export const PUBLICATIONS = [
  {
    id: "1",
    title: "Effects of Natural Antioxidants on the Oxidative Stability of Ruminant Meat Products",
    journal: "Journal of Animal Science",
    year: 2023,
    authors: "Bostami, A.B.M.R., et al.",
    link: "https://www.researchgate.net/profile/Abmrubayet-Bostami"
  },
  {
    id: "2",
    title: "Comparative Study of Feed Additives on Growth Performance in Indigenous Beef Cattle",
    journal: "Animal Nutrition and Feed Technology",
    year: 2022,
    authors: "Bostami, A.B.M.R., Kim, S.W.",
    link: "https://www.researchgate.net/profile/Abmrubayet-Bostami"
  },
  {
    id: "3",
    title: "Microbial Contamination Hazards in Traditional Meat Markets: A Food Safety Assessment",
    journal: "Food Control",
    year: 2021,
    authors: "Bostami, A.B.M.R., Ahmed, F.",
    link: "https://www.researchgate.net/profile/Abmrubayet-Bostami"
  },
  {
    id: "4",
    title: "Advancements in Ruminant Rumen Fermentation through Precision Nutrition",
    journal: "Journal of Agricultural Science and Technology",
    year: 2020,
    authors: "Bostami, A.B.M.R.",
    link: "https://www.researchgate.net/profile/Abmrubayet-Bostami"
  }
];

export const PROFESSIONAL_HIGHLIGHTS = [
  { id: "h1", icon: <FlaskConical />, title: "Laboratory Excellence", desc: "Leading advanced nutritional analysis at SNU, Korea and GAU.", category: "Lab" },
  { id: "h2", icon: <Globe />, title: "Field Surveys", desc: "Extensive fieldwork at GAU Experimental Farms across Bangladesh.", category: "Field" },
  { id: "h3", icon: <Users />, title: "Academic Mentorship", desc: "Supervising post-graduate students in Animal Science.", category: "Academic" },
  { id: "h4", icon: <BookOpen />, title: "Curriculum Design", desc: "Developing state-of-the-art syllabus for Nutrition courses.", category: "Academic" },
  { id: "h5", icon: <Microscope />, title: "Quality Inspection", desc: "Conducting rigorous meat quality and safety audits.", category: "Field" },
  { id: "h6", icon: <GraduationCap />, title: "International Keynote", desc: "Presenting findings at global livestock conferences.", category: "Academic" },
];
